package egovframework.example.sample.config;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

@Controller
public class LoginInterceptor  extends HandlerInterceptorAdapter {

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
		// TODO Auto-generated method stub
		
		System.out.println("세션 테스트");
		HttpSession session = request.getSession();
		String displayName = (String) session.getAttribute("displayName");
		
		if(displayName == null) {
			System.out.println("세션에 저장되어있는 displayName : " + displayName);
			
			response.sendRedirect("oauth/loginInfo.do");
			
			return false;
		}
		
		return true;
	}

}
