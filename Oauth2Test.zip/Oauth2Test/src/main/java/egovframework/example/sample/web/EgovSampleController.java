/*
 * Copyright 2008-2009 the original author or authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package egovframework.example.sample.web;

import java.util.List;
import java.util.Map;

import egovframework.example.sample.service.EgovSampleService;
import egovframework.example.sample.service.SampleDefaultVO;
import egovframework.example.sample.service.SampleVO;

import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.lang3.StringEscapeUtils;
import org.egovframe.rte.fdl.property.EgovPropertyService;
import org.egovframe.rte.ptl.mvc.tags.ui.pagination.PaginationInfo;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.support.SessionStatus;
import org.springframework.web.servlet.ModelAndView;
import org.springmodules.validation.commons.DefaultBeanValidator;

/**
 * @Class Name : EgovSampleController.java
 * @Description : EgovSample Controller Class
 * @Modification Information
 * @
 * @  수정일      수정자              수정내용
 * @ ---------   ---------   -------------------------------
 * @ 2009.03.16           최초생성
 *
 * @author 개발프레임웍크 실행환경 개발팀
 * @since 2009. 03.16
 * @version 1.0
 * @see
 *
 *  Copyright (C) by MOPAS All right reserved.
 */

@Controller
public class EgovSampleController {

	/** EgovSampleService */
	@Resource(name = "sampleService")
	private EgovSampleService sampleService;

	/** EgovPropertyService */
	@Resource(name = "propertiesService")
	protected EgovPropertyService propertiesService;

	/** Validator */
	@Resource(name = "beanValidator")
	protected DefaultBeanValidator beanValidator;

	/**
	 * 글 목록을 조회한다. (pageing)
	 * @param searchVO - 조회할 정보가 담긴 SampleDefaultVO
	 * @param model
	 * @return "egovSampleList"
	 * @exception Exception
	 */
	@RequestMapping(value = "/egovSampleList.do")
	public String selectSampleList(@ModelAttribute("searchVO") SampleDefaultVO searchVO, ModelMap model, HttpServletRequest request) throws Exception {
		
		
		
//		long sessionTime = session.getMaxInactiveInterval();
//		long systemTime = System.currentTimeMillis();
//		long minusTime = (systemTime - sessionTime) / 1000;
//		
//		System.out.println("세션에 저장되어있는 세션시간 : " + minusTime);
		/** EgovPropertyService.sample */
		searchVO.setPageUnit(propertiesService.getInt("pageUnit"));
		searchVO.setPageSize(propertiesService.getInt("pageSize"));

		/** pageing setting */
		PaginationInfo paginationInfo = new PaginationInfo();
		paginationInfo.setCurrentPageNo(searchVO.getPageIndex());
		paginationInfo.setRecordCountPerPage(searchVO.getPageUnit());
		paginationInfo.setPageSize(searchVO.getPageSize());

		searchVO.setFirstIndex(paginationInfo.getFirstRecordIndex());
		searchVO.setLastIndex(paginationInfo.getLastRecordIndex());
		searchVO.setRecordCountPerPage(paginationInfo.getRecordCountPerPage());

		List<?> sampleList = sampleService.selectSampleList(searchVO);
		model.addAttribute("resultList", sampleList);

		int totCnt = sampleService.selectSampleListTotCnt(searchVO);
		paginationInfo.setTotalRecordCount(totCnt);
		model.addAttribute("paginationInfo", paginationInfo);
		
		return "sample/egovSampleList";
	}
	
	@RequestMapping(value = "oauth/loginInfo.do")
    public ModelAndView oauthLoginInfo(HttpServletResponse response,	HttpServletRequest request) throws Exception{
		ModelAndView mav = new ModelAndView();

		String returnURL = "";
		
		//mav.addObject("client_id", "415066915313-of5ku9doobqd10vsupscc476f50jfpit.apps.googleusercontent.com"); //구글 클라이언트 id
		mav.addObject("client_id", "5cb5544b-96bc-429e-9f26-25025f559d00"); //azure 클라이언트 id
		mav.addObject("redirect_uri", "http://localhost:8081/securitygoogletest/oauth2/client/callback.do");
		//mav.addObject("scope", "email profile openid");//구글 스코프
		mav.addObject("scope", "IMAP.AccessAsUser.All POP.AccessAsUser.All SMTP.Send User.Read Mail.Read openid offline_access"); //azure 스코프
		//mav.addObject("access_type", "offline"); //구글
		mav.addObject("prompt", "login"); //azure
		mav.addObject("response_type", "code"); //공통
		//returnURL = "redirect:"+ "https://accounts.google.com/o/oauth2/v2/auth"; //구글 인증코드가져오는 주소
		returnURL = "redirect:"+ "https://login.microsoftonline.com/9135f879-51b0-4368-a2a0-49dfc289ae43/oauth2/v2.0/authorize"; //azure 인증코드가져오는 주소
		
		mav.setViewName(returnURL);
		return mav;
		
		
		
	}
	
	@RequestMapping(value = "oauth2/client/callback.do")
	public ModelAndView authorizeCallback(HttpServletResponse response,	HttpServletRequest request) throws Exception{
		ModelAndView mav = new ModelAndView();
		
		String code = request.getParameter("code");
		
		System.out.println("test : " + code);
		
		HttpClient client = new HttpClient();
		
		int status = 404;
		String body = "";
		
		//String clientId = "415066915313-of5ku9doobqd10vsupscc476f50jfpit.apps.googleusercontent.com"; //구글 클라이언트id
		String clientId = "5cb5544b-96bc-429e-9f26-25025f559d00"; //azure 클라이언트id
		//String clientSecret = "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"; //구글 시크릿
		String clientSecret = "ijM8Q~cvUWaP2W5SzmwiI5p9gbqPiGnZrUR2~cyY"; //azure 시크릿

		
		String redirectUri = "http://localhost:8081/securitygoogletest/oauth2/client/callback.do";
		        
		//String url = "https://www.googleapis.com/oauth2/v4/token"; //구글 토큰정보가져오는 주소
		String url = "https://login.microsoftonline.com/9135f879-51b0-4368-a2a0-49dfc289ae43/oauth2/v2.0/token"; //azure 토큰정보가져오는 주소
		
		String returnURL = "";
		
		NameValuePair[] data = {
			    new NameValuePair("code", code),
			    new NameValuePair("client_id", clientId),
			    new NameValuePair("client_secret", clientSecret),
			    new NameValuePair("redirect_uri", redirectUri),
			    new NameValuePair("grant_type", "authorization_code"),
			    new NameValuePair("access_type", "offline")
	    };

		PostMethod conn = new PostMethod(url);

		conn.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		//conn.setRequestHeader("Content-Type", "application/json");
		conn.setRequestBody(data);
		
		status = client.executeMethod(conn);
		body = conn.getResponseBodyAsString();

		System.out.println("token status : " + status);
		System.out.println("token body : " + body);
		//String[] args = body.split(" "); //구글했을때 나누기
		String[] args = body.split("\"");
		
		for(int i = 0; i < args.length; i++) {
			System.out.println("args[i] : " + args[i]);
			
			if(args[i].equals("access_token")) //azure용
				mav.addObject("access_token", args[i+2]); //azure용
			//if(args[i].trim().replace(":", "").replace("\"","").equals("id_token")) //구글용
			//mav.addObject("id_token", args[i+1].trim().replace(":", "").replace("\"","").replace(",", "")); //구글용
			
		}
		
		
		returnURL = "redirect:"+ "http://localhost:8081/securitygoogletest/oauth2/client/token.do";
		mav.setViewName(returnURL);
		return mav;
	}
	
	@RequestMapping(value = "oauth2/client/token.do")
	public String authorizeToken(HttpServletResponse response,	HttpServletRequest request) throws Exception{
		String access_token = request.getParameter("access_token");
		
		System.out.println("access_token : " + access_token);
		
		//String url = "https://www.googleapis.com/drive/v2/files"; //구글드라이브용
		//String url = "https://oauth2.googleapis.com/tokeninfo"; //구글용
		String url = "https://graph.microsoft.com/v1.0/me";
		
		GetMethod conn = new GetMethod(url);
		
		HttpClient client = new HttpClient();
		
		int status = 404;
		String body = "";
		
		conn.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
		//conn.setRequestHeader("Content-Type", "text/html; charset=utf-8");
		
		NameValuePair[] data = {
				
				new NameValuePair("access_token", access_token)
			    //new NameValuePair("id_token", id_token) //구글용

	    };
		
		//conn.setQueryString(data); 구글용
		conn.setRequestHeader("Authorization", "Bearer " + access_token);
		

		
		status = client.executeMethod(conn);
		body = conn.getResponseBodyAsString();
		
		System.out.println("file status : " + status);
		System.out.println("file body : " + body);
		
		String testsss = StringEscapeUtils.unescapeJava(body);
		
		System.out.println("file body escape : " + testsss);
		
		
		
		String[] args = testsss.split("\"");
		String displayName = "";
		for(int i = 0; i < args.length; i++) {
			
			
			if(args[i].equals("displayName")) {
				System.out.println("args[i] : " + args[i+2]);
				displayName = args[i+2];
			}
			
		}
		
		HttpSession session = request.getSession();
		session.setAttribute("displayName", displayName);
		
		
		
		return "forward:/egovSampleList.do";
	}
	

	/**
	 * 글 등록 화면을 조회한다.
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "egovSampleRegister"
	 * @exception Exception
	 */
	@RequestMapping(value = "/addSample.do", method = RequestMethod.GET)
	public String addSampleView(@ModelAttribute("searchVO") SampleDefaultVO searchVO, Model model) throws Exception {
		model.addAttribute("sampleVO", new SampleVO());
		return "sample/egovSampleRegister";
	}

	/**
	 * 글을 등록한다.
	 * @param sampleVO - 등록할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/egovSampleList.do"
	 * @exception Exception
	 */
	@RequestMapping(value = "/addSample.do", method = RequestMethod.POST)
	public String addSample(@ModelAttribute("searchVO") SampleDefaultVO searchVO, SampleVO sampleVO, BindingResult bindingResult, Model model, SessionStatus status)
			throws Exception {

		// Server-Side Validation
		beanValidator.validate(sampleVO, bindingResult);

		if (bindingResult.hasErrors()) {
			model.addAttribute("sampleVO", sampleVO);
			return "sample/egovSampleRegister";
		}

		sampleService.insertSample(sampleVO);
		status.setComplete();
		return "forward:/egovSampleList.do";
	}

	/**
	 * 글 수정화면을 조회한다.
	 * @param id - 수정할 글 id
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param model
	 * @return "egovSampleRegister"
	 * @exception Exception
	 */
	@RequestMapping("/updateSampleView.do")
	public String updateSampleView(@RequestParam("selectedId") String id, @ModelAttribute("searchVO") SampleDefaultVO searchVO, Model model) throws Exception {
		SampleVO sampleVO = new SampleVO();
		sampleVO.setId(id);
		// 변수명은 CoC 에 따라 sampleVO
		model.addAttribute(selectSample(sampleVO, searchVO));
		return "sample/egovSampleRegister";
	}

	/**
	 * 글을 조회한다.
	 * @param sampleVO - 조회할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return @ModelAttribute("sampleVO") - 조회한 정보
	 * @exception Exception
	 */
	public SampleVO selectSample(SampleVO sampleVO, @ModelAttribute("searchVO") SampleDefaultVO searchVO) throws Exception {
		return sampleService.selectSample(sampleVO);
	}

	/**
	 * 글을 수정한다.
	 * @param sampleVO - 수정할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/egovSampleList.do"
	 * @exception Exception
	 */
	@RequestMapping("/updateSample.do")
	public String updateSample(@ModelAttribute("searchVO") SampleDefaultVO searchVO, SampleVO sampleVO, BindingResult bindingResult, Model model, SessionStatus status)
			throws Exception {

		beanValidator.validate(sampleVO, bindingResult);

		if (bindingResult.hasErrors()) {
			model.addAttribute("sampleVO", sampleVO);
			return "sample/egovSampleRegister";
		}

		sampleService.updateSample(sampleVO);
		status.setComplete();
		return "forward:/egovSampleList.do";
	}

	/**
	 * 글을 삭제한다.
	 * @param sampleVO - 삭제할 정보가 담긴 VO
	 * @param searchVO - 목록 조회조건 정보가 담긴 VO
	 * @param status
	 * @return "forward:/egovSampleList.do"
	 * @exception Exception
	 */
	@RequestMapping("/deleteSample.do")
	public String deleteSample(SampleVO sampleVO, @ModelAttribute("searchVO") SampleDefaultVO searchVO, SessionStatus status) throws Exception {
		sampleService.deleteSample(sampleVO);
		status.setComplete();
		return "forward:/egovSampleList.do";
	}

}
